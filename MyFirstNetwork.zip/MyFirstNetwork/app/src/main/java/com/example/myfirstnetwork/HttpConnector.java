package com.example.myfirstnetwork;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.widget.EditText;
import android.widget.Toast;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;



public class HttpConnector extends AsyncTask<Void,Integer,String> {
    Context c;
    String address;
    String kilometer;
    EditText miles;
    public HttpConnector( String address, String km,EditText et) {//Context c,
        //this.c = c;
        this.address = address;
        this.kilometer = km;
        this.miles=et;
    }
    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);



        if(s != null)
        {

            miles.setText(s);

        }else
        {
            Toast.makeText(c,"Unable to download data", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    protected String doInBackground(Void... voids) {
        String data=getMile(kilometer);

        return data;

    }
    @Override
    protected void onProgressUpdate(Integer... progress) {
        // receive progress updates from doInBackground
    }

    private String getMile(String km)
    {
        //connect and get a stream
        InputStream is=null;
        String line;

        try {

            URL url=new URL(address);
            HttpURLConnection conn= (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoInput(true);
            conn.setDoOutput(true);


            Uri.Builder builder = new Uri.Builder()
                    .appendQueryParameter("km", km);

            String query = builder.build().getEncodedQuery();

            OutputStream os = conn.getOutputStream();
            BufferedWriter writer = new BufferedWriter(
                    new OutputStreamWriter(os, "UTF-8"));
            try {

                writer.write(String.valueOf(query));
                writer.flush();
            }
            catch(Exception ex) {
                ex.printStackTrace();
            }
            finally {
                writer.close();
                os.close();
            }
            // con.connect();



            is=new BufferedInputStream(conn.getInputStream());

            BufferedReader br=new BufferedReader(new InputStreamReader(is));

            StringBuffer sb=new StringBuffer();

            if(br != null) {

                while ((line=br.readLine()) != null) {
                    sb.append(line+"\n");
                }

            }else {
                return null;
            }
            conn.disconnect();
            return sb.toString();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(is != null)
            {
                try {
                    is.close();

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }
}
