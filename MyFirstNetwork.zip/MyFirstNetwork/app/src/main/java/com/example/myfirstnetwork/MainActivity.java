package com.example.myfirstnetwork;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import androidx.appcompat.app.AppCompatActivity;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
  EditText km,miles;
  ImageView imgView;
  String url="https://www.mmsoshub.com/converter.php";
  String imageUrl="https://www.mmsoshub.com/images/logo.png";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.ic_launcher_foreground);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        km=findViewById(R.id.kmText);
        miles=findViewById(R.id.mileText);
        imgView=findViewById(R.id.imageView);
        RequestOptions options = new RequestOptions()
                .error(R.drawable.ic_launcher_foreground);
        Glide.with(this)
                .load(imageUrl)
                .apply(options)
                .into(imgView);
        km.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {


                    if(!checkConenction()) {

                        return true;
                    }
                }
                return false;
            }
        });
    }
    private boolean checkConenction() {
        // get Connectivity Manager object to check internet connection
        ConnectivityManager connMgr
                =(ConnectivityManager)getSystemService(getBaseContext().CONNECTIVITY_SERVICE);

        // Check for network connections
        if ( connMgr.getNetworkInfo(0).getState() ==
                android.net.NetworkInfo.State.CONNECTED ||
                connMgr.getNetworkInfo(0).getState() ==
                        android.net.NetworkInfo.State.CONNECTING ||
                connMgr.getNetworkInfo(1).getState() ==
                        android.net.NetworkInfo.State.CONNECTING ||
                connMgr.getNetworkInfo(1).getState() == android.net.NetworkInfo.State.CONNECTED ) {
                final HttpConnector hp =new HttpConnector(url,km.getText().toString(),miles);
                hp.execute();

            return true;
        }else if (
                connMgr.getNetworkInfo(0).getState() ==
                        android.net.NetworkInfo.State.DISCONNECTED ||
                        connMgr.getNetworkInfo(1).getState() ==
                                android.net.NetworkInfo.State.DISCONNECTED  ) {
            Toast.makeText(this, " Internet not Connected ", Toast.LENGTH_LONG).show();
            return false;
        }
        return false;
    }
}
